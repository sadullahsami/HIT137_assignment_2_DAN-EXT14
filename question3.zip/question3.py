
import turtle

def draw_edge_inward(length, depth):
    if depth == 0:
        turtle.forward(length)
    else:
        third = length / 3.0

        draw_edge_inward(third, depth - 1)

        turtle.right(60)
        draw_edge_inward(third, depth - 1)
        turtle.left(120)
        draw_edge_inward(third, depth - 1)
        turtle.right(60)
        draw_edge_inward(third, depth - 1)

def draw_polygon(sides, side_length, depth):
    angle = 360.0 / sides
    turtle.penup()

    turtle.backward(side_length / 2.0)
    turtle.pendown()

    for _ in range(sides):
        draw_edge_inward(side_length, depth)
        turtle.right(angle)

def main():
    try:
        sides = int(input("Enter the number of sides: ").strip())
        length = float(input("Enter the side length (pixels): ").strip())
        depth = int(input("Enter the recursion depth: ").strip())
    except Exception as e:
        print("Invalid input:", e)
        return

    turtle.setup(width=900, height=700)
    turtle.speed(0)
    turtle.hideturtle()
    turtle.title("Recursive Inward Indentation Polygon")
    turtle.pensize(1)

    draw_polygon(sides, length, depth)

    turtle.done()

if __name__ == "__main__":
    main()


