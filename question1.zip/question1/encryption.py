
def encrypt(data, shift1, shift2):

  encode = []
  for char in data:
    if char>='a' and char<='m':
      cnv = ord(char) - ord('a')
      add_ = (cnv + (shift1*shift2)) % 26
      new = chr(add_ + ord('a') )
      encode.append(new)
    elif char>='n' and char<='z':
      cnv = ord(char) - ord('a')
      add_ = (cnv - (shift1+shift2)) % 26
      new = chr(add_ + ord('a'))
      encode.append(new)

    elif char>='A' and char<='M':
      cnv = ord(char) - ord('A')
      add_ = (cnv - (shift1)) % 26
      new = chr(add_ + ord('A') )
      encode.append(new)

    elif char>='N' and char<='Z':
      cnv = ord(char) - ord('A')
      add_ = (cnv + (shift2**2)) % 26
      new = chr(add_ + ord('A') )
      encode.append(new)
    else:
      encode.append(char)
  encoded = "".join(encode)
  # print(encoded)
  return encoded




