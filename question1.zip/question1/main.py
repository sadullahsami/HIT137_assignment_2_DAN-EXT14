from scipy.fftpack import shift
from encryption import encrypt
from decryption import decrypt

def program(shift1, shift2):

  # encryption
  with open("raw_text.txt","r") as raw_file:
    raw_txt = raw_file.read()

  encoded = encrypt(raw_txt,shift1,shift2)

  with open("encrypted_text.txt",'w') as enc_file:
    enc_file.write(encoded)


  # decryption


  with open("encrypted_text.txt","r") as enc_file:
    enc_txt = enc_file.read()
  
  decoded = decrypt(enc_txt,shift1, shift2)

  with open("decrypted_text.txt",'w') as decrypt_file:
    decrypt_file.write(decoded)
  
  # validation

  flag=0
  for ch1, ch2  in zip(raw_txt, decoded):
  
    if ch1!= ch2:
      flag=1
      break
  if flag==0:
    print("verfication successful")
  else:
    print("verification unsuccessful")


if __name__ == "__main__":
  shift1 = int(input("(input any number) shift1:"))
  shift2 = int(input("(input any number) shift2:"))
  program(1,2)
      