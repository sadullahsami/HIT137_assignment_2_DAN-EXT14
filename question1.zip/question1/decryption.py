def decrypt(encoded,shift1, shift2):
  decode = [] 
  for char in encoded:
    if char>='a' and char<='m':
      cnv = ord(char) - ord('a')
      add_ = (cnv - (shift1*shift2)) % 26
      new = chr(add_ + ord('a') )
      decode.append(new)
    elif char>='n' and char<='z':
      cnv = ord(char) - ord('a')
      add_ = (cnv + (shift1+shift2)) % 26
      new = chr(add_ + ord('a'))
      decode.append(new)

    elif char>='A' and char<='M':
      cnv = ord(char) - ord('A')
      add_ = (cnv + (shift1)) % 26
      new = chr(add_ + ord('A') )
      decode.append(new)

    elif char>='N' and char<='Z':
      cnv = ord(char) - ord('A')
      add_ = (cnv - (shift2**2)) % 26
      new = chr(add_ + ord('A') )
      decode.append(new)
    else:
      decode.append(char)
  decoded = "".join(decode)
  # print(decoded)
  return decoded